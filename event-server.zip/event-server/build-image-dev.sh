#!/bin/bash
podman build --file Dockerfile_dev --ignorefile dockerignore_dev --tag product-srv:latest .
