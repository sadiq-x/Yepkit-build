#!/bin/bash
podman run -ti --rm \
	--pod yepkitcom \
	--name product-srv \
	--env SERVICE_PORT=3006 \
	--env MONGODB_URI="mongodb://127.0.0.1:27017" \
	--env KAFKA_BROKER="127.0.0.1:9092" \
	--env KEY_MANAGER_HOST="127.0.0.1" \
	--env KEY_MANAGER_PORT=3008 \
  	--volume /mnt/storage-ext4/projects/yepkit.com/web/services/product-srv:/srv \
	product-srv:dev

