#!/bin/bash
# Criar graficos com o Graphviz
dot -Tpdf event-srv.gv -o event-srv-graph.pdf 
