import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';

const port = process.env.SERVICE_PORT || 3013;

const wss = new WebSocketServer({ port: port });

let wipConn = new Map();
let clients = new Map();
let subscriptions = new Map();

function handleIncomingMessage(data) {
  try {
    const event = JSON.parse(data);
    console.log(event);
    if ((event.type === "register-response") 
      && event.uid 
      && event.groupId 
      && event.clientId)
    {
      clients.set(
        event.clientId, 
        {ws: wipConn.get(event.uid).ws, groupId: event.groupId}
      );
      wipConn.delete(event.uuid);
      const registerOkMsg = {
        type: "register-confirmed"
      };
      clients.get(event.clientId).ws.send(JSON.stringify(registerOkMsg));
    } else if (event.type === "event" && event.clientId && event.topic) {
      event.uid = uuidv4();
      console.log("subscriptions:", subscriptions);
      // Cada evento que chegar temos de persistir na base de dados.
      // Cada envio bem sucedido tem de ser marcado na base de dados 
      // com o clientId para o qual já foi enviado.
      console.log(event);
      const sub = subscriptions.get(event.topic);
      let sentClients = [];
      for (let clientId of sub.clients) {
        clients.get(clientId).ws.send(JSON.stringify(event), err => {
          if (!err) {
            // ToDo: send the message "" to a database collection
            // with the name of the topic
            // Persistir na base de dados
            let doc = {
              event: event,
              sentTo: sentClients   // Array de clientId(s) aos quais o evento já
                                    // foi enviado.
            };
            console.log("!!!");
            console.log("ToDo - save event in database:", doc);
            console.log("!!!");
          } else {
            sentClients.push(clientId);
          }
        });
      }
    } else if (event.type === "subscription" && event.topic && event.clientId) {
      if (subscriptions.has(event.topic)) {
        let sub = subscriptions.get(event.topic);
        if (sub.clients.find(x => x === event.clientId)) {
          // do nothing because client is already subscribed
        } else {
          sub.clients.push(event.clientId);
        }
      } else {
        subscriptions.set(event.topic, {clients: [event.clientId]});
      }
    }
  } catch (err) {
    console.log(Date.now(), err);
  }
}


function cleanWipConn(uuid) {
  wipConn.delete(uuid)
}

wss.on('connection', function connection(ws) {
  ws.on('message', handleIncomingMessage);

  // Send register request command
  const msg = {
    type: "register-request",
    uid: uuidv4()
  };
  console.log(Date.now(), "Connection requested");
  // Store ws in a map
  wipConn.set(msg.uid, {ws: ws});
  // Set a timeout to clean entry if exists
  setTimeout(cleanWipConn, 10000, msg.uid);
  ws.send(JSON.stringify(msg));
});

