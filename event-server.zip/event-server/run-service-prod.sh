#!/bin/bash
podman run -d \
	--name event-srv \
	--env SERVICE_PORT=3013 \
	-p 3013:3013 \
	event-srv:latest

