#!/bin/bash
podman build --file Dockerfile --ignorefile .dockerignore --tag event-srv:latest .
